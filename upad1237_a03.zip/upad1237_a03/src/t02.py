"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants

from functions import Stack

def stack_combine(source1, source2):
    """
    Combine the contents of two stacks into the first stack.
    """
    while not source2.is_empty():
        source1.push(source2.pop())

def test_stack_combine():
    source1 = Stack()
    source2 = Stack()

    # Push values onto both stacks
    for value in [5, 8, 12]:
        source1.push(value)
    for value in [9, 14, 7]:
        source2.push(value)

    stack_combine(source1, source2)  # Combine source2 into source1

    print("Combined Stack:", source1._values)  # Expected: [5, 8, 12, 9, 14, 7]

test_stack_combine()

