"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-26"
-------------------------------------------------------
"""
# Imports

from List_linked import List
from Food import Food


l = List()
l.append(5)
l.append(67)
l.append(99)


l.insert(1, 33)


l.prepend(10)

print("Integer List after appending, inserting, and prepending:")
for v in l:
    print(v)


assert l._front._value == 10  
assert l._front._next._value == 5 
assert l._front._next._next._value == 33 
assert l._front._next._next._next._value == 67  
assert l._front._next._next._next._next._value == 99  


food_list = List()
food_list.append(Food("Apple", 0, True, 95))  
food_list.append(Food("Banana", 1, True, 105))  
food_list.append(Food("Cherry", 2, False, 150))  


food_list.insert(1, Food("Orange", 3, True, 80))  


food_list.prepend(Food("Mango", 4, True, 60)) 

print("Food List after appending, inserting, and prepending:")
for food in food_list:
    print(food)


assert food_list._front._value.name == "Mango"  
assert food_list._front._next._value.name == "Apple"  
assert food_list._front._next._next._value.name == "Orange"  
assert food_list._front._next._next._next._value.name == "Banana"  
assert food_list._front._next._next._next._next._value.name == "Cherry" 

print("List operations tests passed.")