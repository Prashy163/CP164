"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""
# Imports

# Constants
# -------------------------------------------------------
# Queue Implementation and Solutions
# -------------------------------------------------------
class _Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node

        
        
class Queue:
    def __init__(self):
        self._front = None
        self._rear = None
        self._count = 0

    def insert(self, value):
        new_node = _Node(value)  
        if self._rear is None:
            self._front = new_node
        else:
            self._rear.next = new_node
        self._rear = new_node
        self._count += 1

    def remove(self):
        if self._front is None:
            raise ValueError("Queue is empty")
        value = self._front.value
        self._front = self._front.next
        if self._front is None:
            self._rear = None
        self._count -= 1
        return value

    def _append_queue(self, source):
        """
        Appends the entire source queue to the rear of the current queue.
        """
        if source._front is None:
            return  # Nothing to append

        if self._rear is None:
            self._front = source._front
        else:
            self._rear.next = source._front

        self._rear = source._rear
        self._count += source._count

        source._front = None
        source._rear = None
        source._count = 0

# Testing _append_queue
q1 = Queue()
q2 = Queue()
q1.insert(1)
q1.insert(2)
q2.insert(3)
q2.insert(4)
q1._append_queue(q2)

assert q1.remove() == 1
assert q1.remove() == 2
assert q1.remove() == 3
assert q1.remove() == 4
print("Queue append test passed.")
