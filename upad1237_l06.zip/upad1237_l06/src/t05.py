"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-26"
-------------------------------------------------------
"""
# Imports

# Constants
from List_linked import List


l = List()
l.append(5)
l.append(99)


print("Testing remove method:")
l.remove(99) 
for v in l:
    print(v)  


print("\nTesting peek method:")
try:
    print(l.peek()) 
except IndexError as e:
    print(e)  

print("\nTesting accessing and modifying the first element:")
print(l[0])  
l[0] = 66
print(l[0])  