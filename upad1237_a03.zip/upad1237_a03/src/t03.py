"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports


# Constants
from functions import Stack, stack_reverse

def test_stack_reverse():
    source = Stack()
    
    for value in [5, 8, 12, 8]:
        source.push(value)

    stack_reverse(source)

    print("Reversed Stack:", source._values)

test_stack_reverse()
