"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-01"
-------------------------------------------------------
"""
# Imports

# Constants

from List_linked import List
l1  = List()
l2 = List()
l1.append(1)
l2.append(1)
print(l1.is_identical_r(l2))


