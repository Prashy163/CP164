"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-25"
-------------------------------------------------------
"""
# Imports

from Sorts_List_linked import Sorts
from List_linked import List
from Deque_linked import Deque
from Sorts_array import Sorts

# Constants


a = list()
a.append(30) 
a.append(25)
a.append(4) 
a.append(67)
a.append(25098) 
a.append(58)
a.append(1234321)

Sorts.radix_sort(a)

print(a)
