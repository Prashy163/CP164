"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from morse import fill_code_bst, decode_morse, DATA1

# Constants
bst = BST()
fill_code_bst(bst, DATA1)
morse_code = "... --- ..."
decoded_text = decode_morse(bst, morse_code)
print(f"The Morse Code: {morse_code}")
print(f"The Decoded Text: {decoded_text}")