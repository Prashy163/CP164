"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-16"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
# Constants
def test_bst_methods():
    print("Testing BST Methods")

    # Create a new BST
    bst = BST()

    
    values = [3, 1, 5, 0, 2, 4, 6]
    for value in values:
        bst.insert(value)

    
    bst2 = BST()
    for value in values:
        bst2.insert(value)
    print("BSTs equal:", bst == bst2)  
    
    
    print("Is balanced:", bst.is_balanced())  

    
    print("Is valid:", bst.is_valid()) 

    
    print("Minimum value:", bst.min())  

    
    print("Leaf count:", bst.leaf_count())  

    
    print("One child count:", bst.one_child_count())  

    
    print("Two child count:", bst.two_child_count())  

    # Test traversals
    print("Inorder:", bst.inorder())  
    print("Preorder:", bst.preorder())  
    print("Postorder:", bst.postorder())  
    print("Levelorder:", bst.levelorder())  

    # Test remove
    print("Removing 1:", bst.remove(1)) 
    print("Inorder after removal:", bst.inorder())  
    
if __name__ == "__main__":
    test_bst_methods()