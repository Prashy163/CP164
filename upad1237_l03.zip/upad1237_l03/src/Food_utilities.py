"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
from Food import Food

def read_foods(filename):
    foods = []
    try:
        with open(filename, 'r') as file:
            for line in file:
                parts = line.strip().split('|')
                if len(parts) == 4:  # Ensure there are four parts
                    name = parts[0]
                    calories = int(parts[1])
                    category = parts[2]
                    is_vegetarian = parts[3].strip().lower() == 'true'
                    foods.append(Food(name, calories, category, is_vegetarian))
    except FileNotFoundError:
        print(f"File {filename} not found.")
    except ValueError:
        print("Error processing the food data.")
    return foods
