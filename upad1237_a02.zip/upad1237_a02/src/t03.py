"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  prashant upadhyay
ID:  169051237
Email: upad1237@mylaurier.ca
_updated_ = "2024-02-10"
-------------------------------------------------------
"""
DATE = int(input("Enter a date in the format DDMMYYYY : "))
year = (DATE // 10000)
day = DATE % 100
month = (DATE // 100) % 100
print(f"The reformatted date: {year}/{month}/{day}")
