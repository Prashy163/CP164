"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
# Imports

# Constants
from BST_linked import BST
from morse import fill_letter_bst, encode_morse, DATA1

bst = BST()

fill_letter_bst(bst, DATA1)

text = "HELLO WORLD"
morse_code = encode_morse(bst, text)
print(f"The Original Text: {text}")
print(f"Encoded Morse Code: {morse_code}")