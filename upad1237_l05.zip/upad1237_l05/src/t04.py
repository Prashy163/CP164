"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-10"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import to_power
base = -3
power = 2
print(to_power(base, power))