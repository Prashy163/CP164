"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
# Imports
from pip._vendor.rich.tree import Tree

# Constants

DATA_TREE = r"""
DATA Tree:

A
 \
  B
   \
    C
     \
      D
       \
        ...
         \
          Z

DATA2 Tree:
       M
      / \
    C     T
   / \   / \
  B   F J   W
 / \ / \ / \ / \
A  D E G I K O Q
               / \
              N   S
                 / \
                P   R
                   / \
                  L   U
                       \
                        V
                         \
                          X
                           \
                            Y
                             \
                              Z

DATA3 Tree:
 E
  \
   T
    \
     A
      \
       O
        \
         I
          \
           N
            \
             S
              \
               ...
                 \
                  Z
"""

def analyze_trees():
    print("Which of these three is the most inefficient tree? Why?")
    print("A: DATA1 is likely the most inefficient BST, because it has height of the amount of elements that are in the list.")
    
    print("\nWhich of these is likely to be the most efficient tree?")
    print("B: DATA2 is likely the most efficient BST, because DATA2 is arranged to be split properly.")
    
    print("\nHow could you (theoretically) figure that out?")
    print("C: To figure out which is the most efficient, you would have to calculate the height of the BST that each dataset produces.")
    print("The tree with the height closest to the theoretical minimum height, which is log2(n) where n is the number of nodes, would be the most efficient one.")
    print("The balanced BST allows for search operations to be performed in O(log n) time, compared to O(n) for a completely unbalanced tree.")

def main():
    # Print the tree data and analysis
    print("Tree Data:")
    print(DATA_TREE)  # Print the raw string containing the tree data
    analyze_trees()

if __name__ == "__main__":
    main()