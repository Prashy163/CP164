"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
class Food:
    def __init__(self, name, calories, category, is_vegetarian):
        self.name = name
        self.calories = calories
        self.category = category
        self.is_vegetarian = is_vegetarian

    def __str__(self):
        return f"{self.name} (Calories: {self.calories}, Category: {self.category}, Vegetarian: {self.is_vegetarian})"
