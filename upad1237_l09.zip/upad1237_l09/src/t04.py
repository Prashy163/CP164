"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-16"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set

# Constants

hset = Hash_Set(5)
for i in range(8):
    hset.insert(i)
    
print("Before rehashing:")
hset.debug()

hset._rehash()

print("\nAfter rehashing:")
hset.debug()
