"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-14"
-------------------------------------------------------
"""
# Imports

# Constants
from Food import Food
from Food_utilities import get_food
f = get_food()
print(f)