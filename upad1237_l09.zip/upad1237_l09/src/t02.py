"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-15"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set

#constants

print("insert:")
hset = Hash_Set(1)
hset.insert(2)
hset.insert(3)
hset.insert(4)
hset.insert(5)

print("Hash set after insert")
for i in hset:
    print(i)
    
print(" ")

print("remove:")

remove = hset.remove(3)

print("Removed value: ", remove)

print("Hash set after remove: ")
for i in hset:
    print(i)
