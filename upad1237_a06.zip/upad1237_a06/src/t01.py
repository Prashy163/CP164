"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
# Imports
from Queue_linked import Queue
# Constants

queue = Queue()
print("Queue empty (True):", queue.is_empty())
print("Queue length (0):", len(queue))

# Test insert and peek
queue.insert(1)
queue.insert(2)
queue.insert(3)
print("Queue after inserts:", list(queue))  
print("Peek front (1):", queue.peek())

# Test remove
value = queue.remove()
print("Removed value (1):", value)
print("Queue after remove:", list(queue))  

# Test combine
q1 = Queue()
q2 = Queue()
q1.insert(1)
q1.insert(3)
q2.insert(2)
q2.insert(4)

target = Queue()
target.combine(q1, q2)
print("Combined queue:", list(target))  

# Test split_alt
result1, result2 = target.split_alt()
print("Split result1:", list(result1))  
print("Split result2:", list(result2))  