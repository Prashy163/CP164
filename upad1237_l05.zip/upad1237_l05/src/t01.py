"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-10"
-------------------------------------------------------
"""
# Imports

# constants

from functions import recurse
sol = recurse(7, 5)
print(sol)
