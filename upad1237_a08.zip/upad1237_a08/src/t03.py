"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-16"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import do_comparisons, letter_table
# Constants


DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DATA2 = "MFTCJPWADHKNRUYBEIGLOQSVXZ"
DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"


# Create BST
bst3 = BST()


for char in DATA3:
    bst3.insert(Letter(char))

file = open("gibbon.txt", "r")


do_comparisons(file, bst3)


print("\nLetter Count/Percent Table:")
letter_table(bst3)


file.close()
