"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-04"
-------------------------------------------------------
"""
# Imports

# Constants
from utilities import array_to_list,list_to_array
from List_array import List
def main():
    llist = List()
    source = [1,2,3]
    array_to_list(llist, source)
    for v in llist:
        print(v)
    target = []
    list_to_array(llist, target)
    print(target)
main()