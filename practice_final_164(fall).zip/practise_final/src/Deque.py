"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""
# Imports
# Complete Deque class definition from the canvas
class _Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node


class Deque:
    def __init__(self):
        self._front = None
        self._rear = None
        self._count = 0

    def insert_front(self, value):
        new_node = _Node(value, self._front)
        if self._rear is None:  # Empty deque
            self._rear = new_node
        self._front = new_node
        self._count += 1

    def insert_rear(self, value):
        new_node = _Node(value)
        if self._rear is None:  # Empty deque
            self._front = new_node
        else:
            self._rear.next = new_node
        self._rear = new_node
        self._count += 1

    def remove_front(self):
        if self._front is None:
            raise ValueError("Deque is empty")
        value = self._front.value
        self._front = self._front.next
        if self._front is None:  # Deque becomes empty
            self._rear = None
        self._count -= 1
        return value

    def reverse(self):
# If the deque is empty or has one element, no changes are needed
        if self._count <= 1:
            return False

        # Initialize pointers
        current = self._front
        self._front, self._rear = self._rear, self._front  # Swap front and rear

        return current

