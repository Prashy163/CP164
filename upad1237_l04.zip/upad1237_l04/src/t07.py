"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-04"
-------------------------------------------------------
"""
# Imports

from utilities import list_test
from Food import Food
# Constants

def main():
    f1 = Food("not spring rolls",1,False,66)
    f2 = Food("spring rolls wrong",2,True,653)
    f3 = Food("good spring rolls",1,True,7)
    source = [f1,f2,f3]
    source2 = [6,8,2]
    list_test(source)
    
    
main()