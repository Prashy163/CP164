"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import is_palindrome_stack

def test_is_palindrome_stack():
    test_cases = [
        "racecar",
        "Otto",
        "Able was I ere I saw Elba",
        "A man, a plan, a canal, Panama!",
        "hello"
    ]
    
    for test in test_cases:
        result = is_palindrome_stack(test)
        print(f"'{test}' is palindrome: {result}")

test_is_palindrome_stack()
