"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-14"
-------------------------------------------------------
"""
# Imports

# Constants

from Food import Food
food = Food("grape",3,True,67)
print(food)
