"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
class PriorityQueue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return len(self.items) == 0

    def enqueue(self, item, priority):
        self.items.append((item, priority))
        self.items.sort(key=lambda x: x[1])  # Sort based on priority

    def dequeue(self):
        if not self.is_empty():
            return self.items.pop(0)[0]  # Return only the item
        return None  # or raise an exception

    def peek(self):
        if not self.is_empty():
            return self.items[0][0]  # Return the item with the highest priority
        return None  # or raise an exception
