"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
class Stack:
    def __init__(self):
        self._values = []  

    def push(self, item):
        self._values.append(item)  
        
    def pop(self):
        if self.is_empty():
            return None 
        return self._values.pop()  

    def peek(self):
        if self.is_empty():
            return None  
        return self._values[-1]  

    def is_empty(self):
        return len(self._values) == 0  

class ArrayStack(Stack):  
    def combine(self, source1, source2):
        
        temp1 = []
        temp2 = []
        
        while not source1.is_empty():
            temp1.append(source1.pop())
        
        
        while not source2.is_empty():
            temp2.append(source2.pop())
        
        
        while temp1 or temp2:
            if temp1:
                self.push(temp1.pop())  
            if temp2:
                self.push(temp2.pop())  

def stack_combine(source1, source2):
    target = Stack()
    
    # Temporary stacks to reverse the original stacks
    temp1 = Stack()
    temp2 = Stack()
    
    # Reverse source1 and source2 into temp1 and temp2
    while not source1.is_empty():
        temp1.push(source1.pop())
    while not source2.is_empty():
        temp2.push(source2.pop())

    # Combine the interleaved stacks into target
    while not temp1.is_empty() or not temp2.is_empty():
        if not temp1.is_empty():
            target.push(temp1.pop())
        if not temp2.is_empty():
            target.push(temp2.pop())

    return target

def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    temp_stack = Stack()
    
    while not source.is_empty():
        temp_stack.push(source.pop())
    
    while not temp_stack.is_empty():
        source.push(temp_stack.pop())


def is_palindrome_stack(string):
    """
    -------------------------------------------------------
    Determines if string is a palindrome. Ignores case, digits, spaces, and
    punctuation in string.
    Use: palindrome = is_palindrome_stack(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        palindrome - True if string is a palindrome, False otherwise (bool)
    -------------------------------------------------------
    """
    cleaned_string = ''.join(filter(str.isalnum, string)).lower()
    stack = Stack()
    
    for char in cleaned_string:
        stack.push(char)

    reversed_string = ''
    while not stack.is_empty():
        reversed_string += stack.pop()

    return cleaned_string == reversed_string


def stack_maze(maze):
    """
    -------------------------------------------------------
    Solves a maze using Depth-First search.
    Use: path = stack_maze(maze)
    -------------------------------------------------------
    Parameters:
        maze - dictionary of points in a maze, where each point
            represents a corridor end or a branch. Dictionary
            keys are the name of the point followed by a list of
            branches, if any. First point is named 'Start', exit
            is named 'X' (dict)
    Returns:
        path - list of points visited before the exit is reached,
            does not include 'Start', but does include 'X'.
            Return None if there is no exit (list of str)
    -------------------------------------------------------
    """
    stack = Stack()
    visited = set()
    path = []

    stack.push('Start')

    while not stack.is_empty():
        current = stack.pop()

        if current in visited:
            continue

        visited.add(current)

        if current == 'X':
            path.append(current)
            return path

        path.append(current)

        for neighbor in maze[current]:
            if neighbor not in visited:
                stack.push(neighbor)

    return None


from enum import Enum

MIRRORED = Enum('MIRRORED', {
    'IS_MIRRORED': "is a mirror",
    'TOO_MANY_LEFT': "too many characters in L",
    'TOO_MANY_RIGHT': "too many characters in R",
    'MISMATCHED': "L and R don't match",
    'INVALID_CHAR': "invalid character",
    'NOT_MIRRORED': "no mirror character"
})

def is_mirror_stack(left, right):
    """
    -------------------------------------------------------
    Determines if left and right stacks are mirror images of each other.
    Use: status = is_mirror_stack(left, right)
    -------------------------------------------------------
    Parameters:
        left - stack of characters (Stack)
        right - stack of characters (Stack)
    Returns:
        status - MIRRORED enum (MIRRORED)
    -------------------------------------------------------
    """
    if left.is_empty() and right.is_empty():
        return MIRRORED.IS_MIRRORED

    if left.is_empty() or right.is_empty():
        return MIRRORED.TOO_MANY_LEFT if not left.is_empty() else MIRRORED.TOO_MANY_RIGHT

    while not left.is_empty() and not right.is_empty():
        if left.pop() != right.pop():
            return MIRRORED.MISMATCHED

    return MIRRORED.TOO_MANY_LEFT if not right.is_empty() else MIRRORED.TOO_MANY_RIGHT
