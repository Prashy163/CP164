"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-01"
-------------------------------------------------------
"""
# Imports

# Constants

from List_linked import List
l = List()
l.append(3)
l.append(5)


p,c,i = l._linear_search_r(5)
print("recursively there is a 3 found at index:",i)