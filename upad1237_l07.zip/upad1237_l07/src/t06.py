"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-01"
-------------------------------------------------------
"""
# Imports
from List_linked import List

# Constants
l = List()
l.append(1)
l.append(2)
l.append(3)
l.append(4)
l.append(5)

for i in l:
    print(i)
l.reverse_r()
print()
for j in l:
    print(j)
print()
print(l._rear._value)
print(l._front._value)

