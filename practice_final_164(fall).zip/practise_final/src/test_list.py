"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""
# Imports
from List import List
# Constants
# Testing split_alt
source = List()
source.insert(5)
source.insert(4)
source.insert(3)
source.insert(2)
source.insert(1)
target1, target2 = source.split_alt()

# Expected: target1 = [1, 3, 5], target2 = [2, 4]
current = target1._front
while current:
    print(current.value, end=" ")  # Should print 1 3 5
    current = current.next
print()

current = target2._front
while current:
    print(current.value, end=" ")  # Should print 2 4
    current = current.next
print()

