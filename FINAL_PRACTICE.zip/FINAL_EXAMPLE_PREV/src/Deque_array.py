"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-17"
-------------------------------------------------------
"""
# Imports

# Constants
from copy import deepcopy

class Deque:
    DEFAULT_SIZE = 50

    def __init__(self, max_size=DEFAULT_SIZE):
        """
        -------------------------------------------------------
        Initializes an empty deque.
        Use: deque = Deque()
        -------------------------------------------------------
        Returns:
            a new Deque object (Deque)
        -------------------------------------------------------
        """
        assert max_size > 0, "Deque size must be > 0"
        self._capacity = max_size
        self._values = [None] * self._capacity
        self._count = 0
        self._front = 1
        self._rear = 0

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the deque is empty.
        Use: b = deque.is_empty()
        -------------------------------------------------------
        Returns:
            True if the deque is empty, False otherwise.
        -------------------------------------------------------
        """
        return self._count == 0

    def is_full(self):
        """
        -------------------------------------------------------
        Determines if the deque is full.
        Use: b = deque.is_full()
        -------------------------------------------------------
        Returns:
            True if the deque is full, False otherwise.
        -------------------------------------------------------
        """
        return self._count == self._capacity

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the size of the deque.
        Use: n = len(deque)
        -------------------------------------------------------
        Returns:
            the number of data elements in the deque (int)
        -------------------------------------------------------
        """
        return self._count

    def size(self):
        """
        -------------------------------------------------------
        Returns the size of the deque.
        Use: n = deque.size()
        -------------------------------------------------------
        Returns:
            the number of data elements in the deque (int)
        -------------------------------------------------------
        """
        return self._count

    def insert_front(self, element):
        """
        -------------------------------------------------------
        Inserts a copy of the data element into the front of the deque.
        Use: deque.insert_front(element)
        -------------------------------------------------------
        Parameters:
            element - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        assert self._count < self._capacity, "Deque is full"
        if self._front == 0:
            self._front = self._capacity - 1
        else:
            self._front -= 1
        self._values[self._front] = deepcopy(element)
        self._count += 1
        return

    def remove_front(self):
        """
        -------------------------------------------------------
        Removes and returns data element from the front of the deque.
        Use: v = deque.remove_front()
        -------------------------------------------------------
        Returns:
            element - the data element at the front of deque (?)
        -------------------------------------------------------
        """
        assert self._count > 0, "Cannot remove from an empty deque"
        ret = self._values[self._front]
        self._values[self._front] = None
        self._front = (self._front + 1) % self._capacity
        self._count -= 1
        return ret

    def insert_end(self, element):
        """
        -------------------------------------------------------
        Inserts a copy of value into the rear of the deque.
        Use: deque.insert_end(element)
        -------------------------------------------------------
        Parameters:
            element - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        assert self._count < self._capacity, "Deque is full"
        self._rear = (self._rear + 1) % self._capacity
        self._values[self._rear] = deepcopy(element)
        self._count += 1
        return

    def remove_end(self):
        """
        -------------------------------------------------------
        Removes and returns data element from the end of the deque.
        Use: v = deque.remove_end()
        -------------------------------------------------------
        Returns:
            element - the data element at the end of deque (?)
        -------------------------------------------------------
        """
        assert self._count > 0, "Cannot remove from an empty deque"
        ret = self._values[self._rear]
        self._values[self._rear] = None
        if self._count == 1:
            self._front = 1
            self._rear = 0
        elif self._rear == 0:
            self._rear = self._capacity - 1
        else:
            self._rear -= 1
        self._count -= 1
        return ret

    def peek_front(self):
        """
        -------------------------------------------------------
        Peeks at the front of deque.
        Use: element = deque.peek_front()
        -------------------------------------------------------
        Returns:
            element - a copy of the data element at the front of deque (?)
        -------------------------------------------------------
        """
        assert self._count > 0, "Cannot peek at an empty deque"
        element = deepcopy(self._values[self._front])
        return element

    def peek_end(self):
        """
        -------------------------------------------------------
        Peeks at the end of deque.
        Use: element = deque.peek_end()
        -------------------------------------------------------
        Returns:
            element - a copy of the data element at the end of deque (?)
        -------------------------------------------------------
        """
        assert self._count > 0, "Cannot peek at an empty deque"
        element = deepcopy(self._values[self._rear])
        return element

    def __str__(self):
        """
        -------------------------------------------------------
        Provides a string representation of the deque for debugging.
        Use: print(deque)
        -------------------------------------------------------
        Returns:
            A string containing the deque's values, front, and rear indices.
        -------------------------------------------------------
        """
        return f"{self._values}, Front: {self._front}, Rear: {self._rear}"

    def __iter__(self):
        """
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the deque
        from front to rear.
        Use: for value in deque:
        -------------------------------------------------------
        Returns:
            value - the next value in the deque (?)
        -------------------------------------------------------
        """
        j = self._front
        count = self._count
        i = 0
        while i < count:
            yield self._values[j]
            i += 1
            j = (j + 1) % self._capacity
