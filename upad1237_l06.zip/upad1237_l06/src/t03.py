"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-26"
-------------------------------------------------------
"""
# Imports

# Constants
from List_linked import List
l = List()
l.append(5)
l.append(67)
l.append(99)
l.append(5)
print(l.count(5))
print(l.max())
print(l.min())