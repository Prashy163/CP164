"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""
# Constants

from functions import matrix_rotate_right
def main():
    print(matrix_rotate_right([[1,2,3],[4,5,6],[7,8,9],[10,12,12]]))
    
main()

