"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import Stack, stack_combine

def test_stack_combine():
    source1 = Stack()
    source2 = Stack()
    
    # Pushing values to source1
    for value in [5, 8, 12, 8]:
        source1.push(value)
    
    # Pushing values to source2
    for value in [3, 6, 1, 7, 9]:
        source2.push(value)
    
    target = stack_combine(source1, source2)
    
    # Print target for verification
    print("Source 1:", source1._values)
    print("Source 2:", source2._values)
    print("Target:", target._values)

test_stack_combine()
