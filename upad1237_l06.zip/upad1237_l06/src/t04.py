"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-26"
-------------------------------------------------------
"""
# Imports

# Constants

from List_linked import List


l = List()
l.append(5)
l.append(67)
l.append(99)
l.append(5)


print("Testing find method:")
print(l.find(56))  
print(l.find(5))  


print("\nTesting __contains__ method:")
print(5 in l)      
print(6 in l)      


print("\nTesting index method:")
try:
    print(l.index(67)) 
    print(l.index(5))   
    print(l.index(100)) 
except ValueError as e:
    print(e)  