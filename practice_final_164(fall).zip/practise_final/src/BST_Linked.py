"""
-------------------------------------------------------
Linked version of the BST ADT.
-------------------------------------------------------
Author: Prashant Upadhyay
ID:     169051237
Email:  upad1237@mylaurier.ca
__updated__ = "2024-11-26"
-------------------------------------------------------
"""
# pylint: disable=W0212
# pylint: disable=E2515
# pylint: disable=E0303
# pylint: disable=W0613
# pylint: disable=E1128

# Imports
from copy import deepcopy
from platform import node
from _collections import deque # Import deque for efficient queue operations


class BST:
    """
    A linked BST class.
    """

    class Node:
        def __init__(self, value):
            self._value = value
            self._left = None
            self._right = None

    def __init__(self):
        self._root = None
        self._count = 0

    def is_valid(self):
        return self._is_valid_aux(self._root, None, None)

    def _is_valid_aux(self, node, min_value, max_value):
        if node is None:
            return True
        if (min_value is not None and node._value <= min_value) or \
           (max_value is not None and node._value >= max_value):
            return False
        return self._is_valid_aux(node._left, min_value, node._value) and \
               self._is_valid_aux(node._right, node._value, max_value)

    def insert(self, value):
        def _insert_rec(node, value):
            if node is None:
                return self.Node(value)
            if value < node._value:
                node._left = _insert_rec(node._left, value)
            elif value > node._value:
                node._right = _insert_rec(node._right, value)
            return node

        self._root = _insert_rec(self._root, value)

    def levelorder(self):
        if self._root is None:
            return []
        result = []
        queue = deque([self._root])
        while queue:
            current = queue.popleft()
            result.append(current._value)
            if current._left:
                queue.append(current._left)
            if current._right:
                queue.append(current._right)
        return result


    def node_counts(self):
        """
        Returns the counts of nodes with 0, 1, and 2 children in the BST.
        """
        # Call the helper function starting from the root
        return self._node_counts_aux(self._root)

    def _node_counts_aux(self, node):
        """
        Helper function to count nodes with 0, 1, and 2 children.
        """
        if node is None:
            return 0, 0, 0  # Base case: no nodes in an empty subtree

        # Recursively count nodes in left and right subtrees
        zero_left, one_left, two_left = self._node_counts_aux(node._left)
        zero_right, one_right, two_right = self._node_counts_aux(node._right)

        # Combine counts from left and right subtrees
        zero, one, two = zero_left + zero_right, one_left + one_right, two_left + two_right

        # Classify the current node
        num_children = sum(1 for child in [node._left, node._right] if child is not None)
        if num_children == 0:
            zero += 1  # Node with no children (leaf node)
        elif num_children == 1:
            one += 1  # Node with one child
        else:
            two += 1  # Node with two children

        return zero, one, two  # Return the counts
        
    
    # DO NOT CHANGE CODE BELOW THIS LINE
    # =======================================================================

def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty BST.
        Use: bst = BST()
        -------------------------------------------------------
        Returns:
            A BST object (BST)
        -------------------------------------------------------
        """
        self._root = None
        self._count = 0

def is_empty(self):
        """
        -------------------------------------------------------
        Determines if bst is empty.
        Use: b = bst.is_empty()
        -------------------------------------------------------
        Returns:
            True if bst is empty, False otherwise.
        -------------------------------------------------------
        """
        return self._root is None

def insert(self, value):
        """
        -------------------------------------------------------
        Inserts a copy of value into bst. Values may appear
        only once in a tree.
        Use: b = bst.insert(value)
        -------------------------------------------------------
        Parameters:
            value - data to be inserted into bst (?)
        Returns:
            inserted - True if value is inserted into bst,
                False otherwise. (boolean)
        -------------------------------------------------------
        """
        self._root, inserted = self._insert_aux(self._root, value)
        return inserted

def _insert_aux(self, node, value):
        """
        -------------------------------------------------------
        Inserts a copy of value into node.
        Private recursive operation called only by insert.
        Use: node, inserted = self._insert_aux(node, value)
        -------------------------------------------------------
        Parameters:
            node - a bst node (_BST_Node)
            value - data to be inserted into the node (?)
        Returns:
            node - the current node (_BST_Node)
            inserted - True if value is inserted into node,
                False otherwise. (boolean)
        -------------------------------------------------------
        """
        if node is None:
            # Create a new node if the current position is empty.
            return _BST_Node(value), True
        elif value < node._value:
            # Insert into the left subtree.
            node._left, inserted = self._insert(node._left, value)
        elif value > node._value:
            # Insert into the right subtree.
            node._right, inserted = self._insert(node._right, value)
        else:
            # Value is already in the tree; do not insert.
            inserted = False
        return node, inserted

def retrieve(self, key):
        """
        -------------------------------------------------------
        Retrieves a copy of a value matching key in bst. (Iterative)
        Use: v = bst.retrieve(key)
        -------------------------------------------------------
        Parameters:
            key - data to search for (?)
        Returns:
            value - value in the node containing key, otherwise None (?)
        -------------------------------------------------------
        """
        node = self._root
        value = None

        while node is not None and value is None:

            if node._value > key:
                node = node._left
            elif node._value < key:
                node = node._right
            elif node._value == key:
                # for comparison counting
                value = deepcopy(node._value)
        return value

def inorder(self):
        """
        -------------------------------------------------------
        Generates a list of the contents of the tree in inorder order.
        Use: a = bst.inorder()
        -------------------------------------------------------
        Returns:
            a - copy of the contents of the tree in inorder (list of ?)
        -------------------------------------------------------
        """
        a = []
        self._inorder_aux(self._root, a)
        return a

def _inorder_aux(self, node, a):
        """
        ---------------------------------------------------------
        Traverses node subtree in inorder. a contains the contents of
        node and its children in inorder.
        Private recursive operation called only by inorder.
        Use: self._inorder_aux(node, a)
        ---------------------------------------------------------
        Parameters:
            node - an BST node (_BST_Node)
            a - target list of data (list of ?)
        Returns:
            None
        ---------------------------------------------------------
        """
        if node is not None:
            self._inorder_aux(node._left, a)
            a.append(deepcopy(node._value))
            self._inorder_aux(node._right, a)
        return

def preorder(self):
        """
        -------------------------------------------------------
        Generates a list of the contents of the tree in preorder order.
        Use: a = bst.preorder()
        -------------------------------------------------------
        Returns:
            a - copy of the contents of the tree in preorder (list of ?)
        -------------------------------------------------------
        """
        a = []
        self._preorder_aux(self._root, a)
        return a

def _preorder_aux(self, node, a):
        """
        ---------------------------------------------------------
        Traverses node subtree in preorder. a contains the contents of
        node and its children in preorder.
        Private recursive operation called only by preorder.
        Use: self._preorder_aux(node, a)
        ---------------------------------------------------------
        Parameters:
            node - an BST node (_BST_Node)
            a - target of data (list of ?)
        Returns:
            None
        ---------------------------------------------------------
        """
        if node is not None:
            a.append(deepcopy(node._value))
            self._preorder_aux(node._left, a)
            self._preorder_aux(node._right, a)
        return

def postorder(self):
        """
        -------------------------------------------------------
        Generates a list of the contents of the tree in postorder order.
        Use: a = bst.postorder()
        -------------------------------------------------------
        Returns:
            a - copy of the contents of the tree in postorder (list of ?)
        -------------------------------------------------------
        """
        a = []
        self._postorder_aux(self._root, a)
        return a

def _postorder_aux(self, node, a):
        """
        ---------------------------------------------------------
        Traverses node subtree in postorder. a contains the contents of
        node and its children in postorder.
        Private recursive operation called only by postorder.
        Use: self._postorder_aux(node, a)
        ---------------------------------------------------------
        Parameters:
            node - an BST node (_BST_Node)
            a - target of data (list of ?)
        Returns:
            None
        ---------------------------------------------------------
        """
        if node is not None:
            self._postorder_aux(node._left, a)
            self._postorder_aux(node._right, a)
            a.append(deepcopy(node._value))
        return

def levelorder(self):
        """
        -------------------------------------------------------
        Copies the contents of the tree in levelorder order to a list.
        Use: values = bst.levelorder()
        -------------------------------------------------------
        Returns:
            values - a list containing the values of bst in levelorder.
            (list of ?)
        -------------------------------------------------------
        """
        if self._root is None:
            return []  # Return an empty list if the tree is empty

        result = []  # List to store the level order traversal
        queue = deque([self._root])  # Initialize the queue with the root node

        while queue:
            current = queue.popleft()  # Get the node at the front of the queue
            result.append(current._value)  # Add the current node's value to the result

            # Enqueue the left and right children if they exist
            if current._left:
                queue.append(current._left)
            if current._right:
                queue.append(current._right)

        return result  # Return the list of values in level order        

def __iter__(self):
        """
        -------------------------------------------------------
        Generates a Python iterator. Iterates through a BST node
        in level order.
        Use: for v in bst:
        -------------------------------------------------------
        Returns:
            yields
            value - the values in the BST node and its children (?)
        -------------------------------------------------------
        """
        if self._root is not None:
            queue = [self._root]
            
        while queue:
            node = queue.pop(0)
            yield node._value  # Yielding the value instead of the node
            if node._left:
                queue.append(node._left)
            if node._right:
                queue.append(node._right)


class _BST_Node:
    """
    A linked BST Node class.
    """

    def __init__(self, value):
        """
        -------------------------------------------------------
        Initializes a BST node containing value. Child pointers
        are None, height is 1.
        Use: node = _BST_Node(value)
        -------------------------------------------------------
        Parameters:
            value - value for the node (?)
        Returns:
            A _BST_Node object (_BST_Node)
        -------------------------------------------------------
        """
        self._value = deepcopy(value)
        self._left = None
        self._right = None
        self._height = 1
        self._count = 0

    def _update_height(self):
        """
        -------------------------------------------------------
        Updates the height of the current node. _height is 1 plus
        the maximum of the node's (up to) two child heights.
        Use: node._update_height()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """
        if self._left is None:
            left_height = 0
        else:
            left_height = self._left._height

        if self._right is None:
            right_height = 0
        else:
            right_height = self._right._height

        self._height = max(left_height, right_height) + 1
        return

    def __str__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Returns node height and value as a string - for debugging.
        -------------------------------------------------------
        """
        return f"h: {self._height}, v: {self._value}"
