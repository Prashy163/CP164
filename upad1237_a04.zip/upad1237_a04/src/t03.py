"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-05"
-------------------------------------------------------
"""
# Imports

# Constants
from Priority_Queue_array import Priority_Queue
def main():
    pq = Priority_Queue()
    pq.insert(99)
    print(pq._values)
    target1, target2 = pq.split_key(100)
    
    print(target1._values)
    print(target2._values)
    
main()