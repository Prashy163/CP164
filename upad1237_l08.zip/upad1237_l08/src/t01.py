"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
#imports

from morse import ByLetter

letter_a = ByLetter('A', '.-')
letter_b = ByLetter('B', '-...')
letter_c = ByLetter('C', '-.-.')

# Displaying string representation of ByLetter objects
print(f"Letter the A: {str(letter_a)}")
print(f"Letter the B: {str(letter_b)}")
print(f"Letter the C: {str(letter_c)}")

aisb = 'Yes' if letter_a == letter_b else 'No'

abeforeb = 'Yes' if letter_a < letter_b else 'No'

aandc = 'Yes' if letter_a <= letter_c else 'No'

# Comparing ByLetter objects
print(f"Is the Letter A equal to Letter B? {aisb}")
print(f"Does the Letter A come before Letter B? {abeforeb}")
print(f"Is the Letter A less than or equal to Letter C? {aandc}")

