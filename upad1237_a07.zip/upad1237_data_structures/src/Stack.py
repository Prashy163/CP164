"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-29"
-------------------------------------------------------
"""
# Imports

# Constants
class Stack:
    def __init__(self):
        """Initialize an empty stack."""
        self._values = []

    def push(self, value):
        """
        Pushes a value onto the stack.
        :param value: The value to be pushed onto the stack.
        """
        self._values.append(value)

    def pop(self):
        """
        Pops the top value off the stack and returns it.
        :return: The value popped from the stack.
        :raises IndexError: If the stack is empty.
        """
        if self.is_empty():
            raise IndexError("pop from an empty stack")
        return self._values.pop()

    def peek(self):
        """
        Returns the top value of the stack without removing it.
        :return: The top value of the stack.
        :raises IndexError: If the stack is empty.
        """
        if self.is_empty():
            raise IndexError("peek from an empty stack")
        return self._values[-1]

    def is_empty(self):
        """
        Checks if the stack is empty.
        :return: True if the stack is empty, False otherwise.
        """
        return len(self._values) == 0

    def size(self):
        """
        Returns the number of items in the stack.
        :return: The size of the stack.
        """
        return len(self._values)

    def __str__(self):
        """
        Returns a string representation of the stack.
        :return: String representation of the stack.
        """
        return str(self._values)
