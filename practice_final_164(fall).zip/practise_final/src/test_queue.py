"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""
# Imports
from queue import Queue

# Constants
# Testing _append_queue
q1 = Queue()
q2 = Queue()
q1.insert(1)
q1.insert(2)
q2.insert(3)
q2.insert(4)
q1._append_queue(q2)

assert q1.remove() == 1
assert q1.remove() == 2
assert q1.remove() == 3
assert q1.remove() == 4
print("Queue append test passed.")

