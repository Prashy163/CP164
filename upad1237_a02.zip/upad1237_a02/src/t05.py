"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  prashant upadhyay
ID:  169051237
Email: upad1237@mylaurier.ca
_updated_ = "2024-02-10"
-------------------------------------------------------
"""
length = float(input("Foundation length (m): "))
width = float(input("Foundation width (m) : "))
height = float(input("Foundation height (m): "))
wall = float(input("Wall height: "))

COST_CONCRETE = float(input("Cost of concrete ($/m^3) : "))
COST_BRICKS = float(input("Cost of bricks ($/m^2) : "))

concrete = float(length * width * height)
total_cost_concrete = float(COST_CONCRETE * concrete)

bricks = float(2 * (length * wall + wall * width))
total_cost_bricks = float(bricks * COST_BRICKS)

TOTAL_COST = float(total_cost_concrete + total_cost_bricks)

print(f'Concrete needed for foundation (m^3): {concrete: .2f}')
print(f'Cost of concrete: ${total_cost_concrete: .2f}')
print(f'Bricks needed for walls (m^2): {bricks: .2f}')
print(f'Cost of bricks: ${total_cost_bricks: .2f}')
print(f'Total cost: ${TOTAL_COST: .2f}')
