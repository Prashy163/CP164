"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import stack_maze

def test_stack_maze():
    maze = {'Start': ['A'], 'A': ['B', 'C'], 'B': [], 'C': ['D', 'E'],
            'D': [], 'E': ['F', 'X'], 'F': ['G', 'H'], 'G': [], 'H': []}

    path = stack_maze(maze)
    print("Path to exit:", path)

test_stack_maze()
