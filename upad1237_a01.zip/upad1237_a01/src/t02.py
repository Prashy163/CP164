"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""
# Imports

# Constants
from functions import is_valid
def main():
    s = "var"
    print(is_valid(s))
    
main()