"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-01"
-------------------------------------------------------
"""
# Imports
from List_linked import List

# Constants
l1 = List()
l1.append(1)
l1.append(2)
l1.append(3)
l1.append(4)
l1.append(5)

l2 = List()
l2.append(3)
l2.append(4)
l2.append(5)
l2.append(6)
l2.append(7)

target_list = List()
target_list.intersection(l1, l2)

for value in target_list:
    print(value)

