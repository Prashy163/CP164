"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-15"
-------------------------------------------------------
"""
# Imports
from Food import Food
from functions import hash_table

# Constants

foods = [
    Food("Lasagna", 7, True, 600),
    Food("Butter Chicken", 2, False, 900), 
    Food("Moo Goo Guy Pan", 3, False, 800),
    Food("Vegetable Alicha", 4, True, 300)
]

slots = 7

print("Testing hash_table function:")
hash_table(slots, foods)


