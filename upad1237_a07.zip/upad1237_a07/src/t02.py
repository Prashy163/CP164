"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-10"
-------------------------------------------------------
"""
# Imports

# Constants


from Sorted_List_linked import Sorted_List
from Food import Food

# test_sorted_list.py

def run_sorted_list_tests():
    with open("testing.txt", "a") as f:
        f.write("\n=== Testing Sorted List Methods ===\n")

        # Create a Sorted_List instance
        sorted_food_list = Sorted_List()

        # Test insert
        sorted_food_list.insert(Food("Banana", 2))
        sorted_food_list.insert(Food("Apple", 1))
        sorted_food_list.insert(Food("Cherry", 3))
        f.write(f"After inserting: {sorted_food_list}\n")

        # Test __contains__
        f.write("Contains Banana: " + str("Banana" in sorted_food_list) + "\n")  # Should return True

        # Test find
        f.write("Find Apple: " + str(sorted_food_list.find(Food("Apple", 1))) + "\n")  # Should return the Apple object

        # Test max and min
        f.write("Max: " + str(sorted_food_list.max()) + "\n")  # Should return Cherry
        f.write("Min: " + str(sorted_food_list.min()) + "\n")  # Should return Apple

        # Test remove
        sorted_food_list.remove(Food("Banana", 2))
        f.write("After removing Banana: " + str(sorted_food_list) + "\n")

        # Test empty sorted list
        empty_sorted_list = Sorted_List()
        f.write("Empty sorted list: " + str(empty_sorted_list) + "\n")

if __name__ == "__main__":
    run_sorted_list_tests()