"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""
#imports
class _Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node
        
# List Implementation and Solutions

class List:
    def __init__(self):
        self._front = None

    def insert(self, value):
        new_node = _Node(value, self._front)
        self._front = new_node

    def split_alt(self):
        """
        Splits the source list into alternating target lists.
        """
        target1 = List()
        target2 = List()
        toggle = True
        
        while self._front is not None:
            current = self._front
            self._front = self._front.next

            if toggle:
                current.next = target1._front
                target1._front = current
            else:
                current.next = target2._front
                target2._front = current

            toggle = not toggle

        return target1, target2

    def _swap(self, pln, prn):
        """
        Swaps two nodes given their predecessors.
        """
        if pln is None or prn is None:
            return  # Cannot swap if either is None

        left_node = pln.next
        right_node = prn.next

        # Update the links
        pln.next, prn.next = right_node, left_node
        left_node.next, right_node.next = right_node.next, left_node.next

