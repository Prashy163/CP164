"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-10"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import  is_palindrome
s = "z526z"
print(is_palindrome(s))