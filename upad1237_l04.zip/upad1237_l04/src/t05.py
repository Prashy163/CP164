"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-04"
-------------------------------------------------------
"""
# Imports

# Constants
from List_array import List
def main():
    l = List()

    l.append(2)
    print(l[0])
    
main()