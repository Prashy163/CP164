"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
# Imports
from Deque_linked import Deque
# Constants

#Test Deque creation and basic operations
deque = Deque()
print("Deque empty (True):", deque.is_empty())
print("Deque length (0):", len(deque))

# Test insertions
deque.insert_front(1)
deque.insert_rear(2)
deque.insert_front(0)
print("Deque after inserts:", list(deque))  

# Test peek operations
print("Peek front (0):", deque.peek_front())
print("Peek rear (2):", deque.peek_rear())

# Test removals
front = deque.remove_front()
rear = deque.remove_rear()
print("Removed front (0):", front)
print("Removed rear (2):", rear)
print("Deque after removes:", list(deque))