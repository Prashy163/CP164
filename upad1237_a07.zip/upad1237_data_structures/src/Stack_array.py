"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-06-15"
-------------------------------------------------------
"""
# Imports

# Working
class Stack:
    def __init__(self):
        self._values = []

    def push(self, item):
        self._values.append(item)

    def pop(self):
        if self.is_empty():
            return None
        return self._values.pop()

    def peek(self):
        if self.is_empty():
            return None
        return self._values[-1]

    def is_empty(self):
        return len(self._values) == 0

    def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines two source stacks into the current target stack.
        When finished, the contents of source1 and source2 are interlaced
        into target and source1 and source2 are empty.
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - an array-based stack (Stack)
            source2 - an array-based stack (Stack)
        Returns:
            None
        -------------------------------------------------------
        """
        while not source1.is_empty() or not source2.is_empty():
            if not source1.is_empty():
                self.push(source1._values.pop())
            if not source2.is_empty():
                self.push(source2._values.pop())
                
                    
                    
    def reverse(self):
        """
        -------------------------------------------------------
        Reverses the contents of the source stack.
        Use: source.reverse()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """
        temp_stack = Stack()
        
        while not self.is_empty():
            temp_stack.push(self._values.pop())
        
        while not temp_stack.is_empty():
            self.push(temp_stack.pop())


