"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-16"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import do_comparisons, comparison_total

#Constants

DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DATA2 = "MFTCJPWADHKNRUYBEIGLOQSVXZ"
DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"

bst1 = BST()
bst2 = BST()
bst3 = BST()

for char in DATA1:
    bst1.insert(Letter(char))
for char in DATA2:
    bst2.insert(Letter(char))
for char in DATA3:
    bst3.insert(Letter(char))

# Open files
file1 = open("gibbon.txt", "r")
file2 = open("otoos610.txt", "r")

# Function to process comparisons and print results
def print_comparison_results(file, bst1, bst2, bst3, filename):
    print(f"Processing {filename}...")

    # Do comparisons for all three BSTs
    do_comparisons(file, bst1)
    do_comparisons(file, bst2)
    do_comparisons(file, bst3)

    # Print results
    print(f"\nComparing by order: {DATA1}")
    print(f"Total Comparisons: {comparison_total(bst1):,}")
    print("------------------------------------------------------------")

    print(f"Comparing by order: {DATA2}")
    print(f"Total Comparisons: {comparison_total(bst2):,}")
    print("------------------------------------------------------------")

    print(f"Comparing by order: {DATA3}")
    print(f"Total Comparisons: {comparison_total(bst3):,}")
    print("------------------------------------------------------------")

# Process gibbon.txt
print_comparison_results(file1, bst1, bst2, bst3, "gibbon.txt")

# Process otoos610.txt
print_comparison_results(file2, bst1, bst2, bst3, "otoos610.txt")


file1.close()
file2.close()
