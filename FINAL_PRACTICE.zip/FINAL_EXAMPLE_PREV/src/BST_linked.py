"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-17"
-------------------------------------------------------
"""
# Imports

# Constants
from copy import deepcopy

class BST:
    
    def reverse(self) -> None:
        """
        ---------------------------------------------------------------
        Changes the current BST into a reverse image of itself. 
        All nodes are swapped with nodes on the opposite side.
        Use: bst.reverse()
        ---------------------------------------------------------------
        Returns:
            None
        ---------------------------------------------------------------
        """
        if self._root is not None:
            self._reverse_aux(self._root)
        return

    def _reverse_aux(self, node)-> None:
        """
        ---------------------------------------------------------------
        Helper function to recursively reverse the subtree rooted at 'node'.
        Use: self._reverse_aux(node)
        ---------------------------------------------------------------
        Parameters:
            node - the root of the current subtree (_BST_Node)
        Returns:
            None
        ---------------------------------------------------------------
        """
        if node is not None:
            # Swap the left and right child nodes
            node._left, node._right = node._right, node._left
            # Recursively reverse left and right subtrees
            self._reverse_aux(node._left)
            self._reverse_aux(node._right)
        return

    def _shift_left(self, parent):
        """
        -----------------------------------------------------------
        Shifts the parent node to its left around its right child.
        Updates the heights of the shifted nodes.
        Use: parent = self._shift_left(parent)
        -----------------------------------------------------------
        Parameters:
            parent - the root of the subtree to shift (_BST_Node)
        Returns:
            updated - the node that replaces the parent node (_BST_Node)
        -----------------------------------------------------------
        """
        assert parent._right is not None, "Cannot perform left shift on a node without a right child."
        
        updated = parent._right
        parent._right = updated._left
        updated._left = parent

        # Update heights of parent and updated nodes
        parent._height = 1 + max(self._get_height(parent._left), self._get_height(parent._right))
        updated._height = 1 + max(self._get_height(updated._left), self._get_height(updated._right))

        return updated

    def _get_height(self, node) -> int:
        """
        -----------------------------------------------------------
        Helper method to safely get the height of a node.
        Use: height = self._get_height(node)
        -----------------------------------------------------------
        Parameters:
            node - the node to check (_BST_Node or None)
        Returns:
            height - the height of the node, or -1 if node is None (int)
        -----------------------------------------------------------
        """
        return node._height if node is not None else -1
