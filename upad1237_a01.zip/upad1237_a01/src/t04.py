"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""

from functions import matrix_flatten
def main():
    print(matrix_flatten([["a", "b"], ["x", "z"], ["e", "f"]]))
    
main()
