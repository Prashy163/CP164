"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: prashant upadhyay
ID:  169051237
Email: upad1237@mylaurier.ca
_updated_ = "2024-02-10"
-------------------------------------------------------
"""
integer = int(input("Enter a positive digit number:"))
if 10 <= integer <= 99:
    TENTH = integer // 10
    ONES = integer % 10
    diff = int(TENTH * ONES)


print(f'The difference of the digits of 69 is {diff}')
