"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-17"
-------------------------------------------------------
"""
# Imports

# Constants
class Deque_Set:
    """
    -------------------------------------------------------
    A deque-based set implementation.
    Stores unique elements in a double-ended queue.
    -------------------------------------------------------
    """
    
    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty Deque_Set.
        Use: d = Deque_Set()
        -------------------------------------------------------
        Returns:
            A new Deque_Set object (Deque_Set)
        -------------------------------------------------------
        """
        self._front = None  # Reference to the front node
        self._rear = None   # Reference to the rear node
        self._count = 0     # Number of elements in the deque
        return

    def _linear_search(self, key):
        """
        -------------------------------------------------------
        Private helper method.
        Searches for a key in a Deque_Set.
        Use: curr = self._linear_search(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (*)
        Returns:
            curr - pointer to node containing key, or None if not found (_Deque_Set_Node)
        -------------------------------------------------------
        """
        curr = self._front  # Start at the front of the deque
        while curr is not None and curr._value != key:
            curr = curr._next
        return curr
    
def _move_front_to_rear(self, source):
    """
    -------------------------------------------------------
    Private helper method.
    Moves the front node from the source Deque_Set to the rear of self.
    Does not validate that self is still a set.
    Use: self._move_front_to_rear(source)
    -------------------------------------------------------
    Parameters:
        source - a non-empty Deque_Set (Deque_Set)
    Returns:
        None
    -------------------------------------------------------
    """
    assert source._front is not None, "Cannot move the front of an empty Deque_Set."

    # Detach the front node from the source
    node = source._front

    if source._front._next is not None:
        # Update the source's front to the next node
        source._front = source._front._next
        source._front._prev = None
    else:
        # Source has only one node, reset front and rear
        source._front = None
        source._rear = None

    source._count -= 1

    # Attach the node to the rear of self
    if self._rear is not None:
        # Link the new node to the current rear
        self._rear._next = node
        node._prev = self._rear
        self._rear = node
    else:
        # If self is empty, set front and rear to the new node
        self._front = self._rear = node

    # Ensure the new rear node points to None
    self._rear._next = None

    self._count += 1
    return


    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty Deque_Set.
        Use: d = Deque_Set()
        -------------------------------------------------------
        Returns:
            new Deque_Set object (Deque_Set)
        -------------------------------------------------------
        """
        self._front = None
        self._rear = None
        self._count = 0

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if a Deque_Set is empty.
        Use: b = source.is_empty()
        -------------------------------------------------------
        Returns:
            True if source is empty, False otherwise.
        -------------------------------------------------------
        """
        return self._count == 0

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the size of a Deque_Set.
        Use: n = len(source)
        -------------------------------------------------------
        Returns:
            the number of values in source (int)
        -------------------------------------------------------
        """
        return self._count

def insert_rear(self, value):
    """
    -------------------------------------------------------
    Inserts a copy of value into the rear of a Deque_Set. 
    Value cannot already be in the Deque_Set.
    Updates _count appropriately.
    Use: source.insert_rear(value)
    -------------------------------------------------------
    Parameters:
        value - a data element (*)
    Returns:
        inserted - True if value is added to rear of source, 
                   False otherwise.
    -------------------------------------------------------
    """
    inserted = False
    curr = self._linear_search(value)

    if curr is None:  # Value not already in the set
        # Create a new node with the given value
        new_node = _Deque_Set_Node(value, self._rear, None)

        # If the Deque_Set is empty, the new node will be both front and rear
        if self._front is None:
            self._front = new_node
        else:
            self._rear._next = new_node  # Link the old rear to the new node

        self._rear = new_node  # Update the rear to the new node
        self._count += 1
        inserted = True

    return inserted

    def remove_front(self):
        """
        -------------------------------------------------------
        Removes and returns value from the front of a Deque_Set.
        Updates _count appropriately.
        Use: v = source.remove_front()
        -------------------------------------------------------
        Returns:
            value - the value at the front of source (*)
        -------------------------------------------------------
        """
        assert self._front is not None, "Cannot remove from an empty Deque_Set."

        value = self._front._value
        if self._front._next is not None:
            self._front = self._front._next
            self._front._prev = None
        else:
            self._front = None
            self._rear = None

        self._count -= 1
        return value

    def remove_rear(self):
        """
        -------------------------------------------------------
        Removes and returns value from the rear of a Deque_Set.
        Updates _count appropriately.
        Use: v = source.remove_rear()
        -------------------------------------------------------
        Returns:
            value - the value at the rear of source (*)
        -------------------------------------------------------
        """
        assert self._rear is not None, "Cannot remove from an empty Deque_Set."

        value = self._rear._value
        if self._rear._prev is not None:
            self._rear = self._rear._prev
            self._rear._next = None
        else:
            self._front = None
            self._rear = None

        self._count -= 1
        return value

    def remove(self, key):
        """
        -------------------------------------------------------
        Finds, removes, and returns the value in source that matches key.
        Updates _count appropriately.
        Use: value = source.remove(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (*)
        Returns:
            value - the full value matching key, otherwise None (*)
        -------------------------------------------------------
        """
        curr = self._linear_search(key)

        if curr is not None:
            if curr._prev is not None:
                curr._prev._next = curr._next
            else:
                self._front = curr._next

            if curr._next is not None:
                curr._next._prev = curr._prev
            else:
                self._rear = curr._prev

            self._count -= 1
            return curr._value
        return None

    def max(self):
        """
        -------------------------------------------------------
        Finds the maximum value in a Deque_Set.
        Use: value = source.max()
        -------------------------------------------------------
        Returns:
            a copy of the maximum value in source (?)
        -------------------------------------------------------
        """
        assert self._front is not None, "Cannot find maximum of an empty Deque_Set."

        curr = self._front
        value = self._front._value

        while curr is not None:
            if value < curr._value:
                value = curr._value
            curr = curr._next

        return value

    def split_key(self, key):
        """
        -------------------------------------------------------
        Splits source so that target1 contains all values < key, and 
        target2 contains all values >= key. Source is empty when finished.
        Nodes are moved, values are not copied.
        Updates _count appropriately.
        Use: target1, target2 = source.split_key(key)
        -------------------------------------------------------
        Parameters:
            key - a key value to split source upon (?)
        Returns:
            target1 - a new Deque_Set of values < key (Deque_Set)
            target2 - a new Deque_Set of values >= key (Deque_Set)
        -------------------------------------------------------
        """
        target1 = Deque_Set()
        target2 = Deque_Set()

        while self._front is not None:
            if self._front._value < key:
                target1._move_front_to_rear(self)
            else:
                target2._move_front_to_rear(self)

        return target1, target2

    def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines source1 and source2 into target.
        When finished, the contents of source1 and source2 are interlaced
        into target and source1 and source2 are empty.
        Order of source values is preserved.
        Values may appear only once in target.
        Nodes are moved, values are not copied.
        Updates _count appropriately.
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - a Deque_Set (Deque_Set)
            source2 - a Deque_Set (Deque_Set)
        Returns:
            None
        -------------------------------------------------------
        """
        assert self._front is None, "Target must be empty."

        while source1._front is not None or source2._front is not None:
            if source1._front is not None:
                if self._linear_search(source1._front._value) is None:
                    self._move_front_to_rear(source1)
                else:
                    source1.remove_front()

            if source2._front is not None:
                if self._linear_search(source2._front._value) is None:
                    self._move_front_to_rear(source2)
                else:
                    source2.remove_front()

        return
