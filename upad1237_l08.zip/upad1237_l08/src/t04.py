"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-08"
-------------------------------------------------------
"""
# Imports

# Constants
from BST_linked import BST
from morse import fill_code_bst, DATA1
bst = BST()
# Fill the BST with Morse code data
fill_code_bst(bst, DATA1)
# Print the BST
print("The BST Contents in Inorder:")
for eachs in bst.inorder():
    print(eachs)