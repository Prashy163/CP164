"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-26"
-------------------------------------------------------
"""
# Imports
from Deque_linked import Deque
from Sorts_array import Sorts

#Constants

d = Deque()

a = [30, 25, 4, 67, 25098, 58, 1234321]
for val in a:
    d.insert_front(val)

print ("Original Deque:")
for i in d:
    print (i)
    
Sorts.gnome_sort(a)

print ("\nAfter Gnome Sort:")
for i in d:
    print (i)
