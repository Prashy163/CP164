"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""

from functions import matrix_stats
def main():
    print(matrix_stats([[1,2],[2,2]]))
    
main()