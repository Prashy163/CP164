"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-10"
-------------------------------------------------------
"""
# Imports

from List_linked import List
from Food import Food

#Constants
# test_list.py

def run_list_tests():
    with open("testing.txt", "a") as f:
        f.write("=== Testing List Methods ===\n")

        # Create a List instance
        food_list = List()

        # Test append with updated Food constructor (adjust based on your Food class definition)
        food_list.append(Food("Apple", True, 20))  
        food_list.append(Food("Banana", True, 105))
        food_list.append(Food("Chicken", False, 335))
        f.write(f"After appending: {food_list}\n")

        # Test __getitem__
        f.write("Item at index 1: " + str(food_list[1]) + "\n")  # Should return Banana

        # Test __eq__
        another_food_list = List()
        another_food_list.append(Food("Apple", True, 95))
        another_food_list.append(Food("Banana", True, 105))
        another_food_list.append(Food("Chicken", False, 335))
        f.write("Lists equal: " + str(food_list == another_food_list) + "\n")  # Should return True

        # Test remove_front
        food_list.remove_front()
        f.write("After removing front: " + str(food_list) + "\n")

        # Test clean
        food_list.clean()
        f.write("After cleaning: " + str(food_list) + "\n")

        # Test intersection
        food_list.append(Food("Apple", True, 95))
        food_list.append(Food("Banana", True, 105))
        another_food_list.append(Food("Banana", True, 105))
        intersection_list = food_list.intersection(another_food_list)
        f.write("Intersection: " + str(intersection_list) + "\n")

        # Test union
        union_list = food_list.union(another_food_list)
        f.write("Union: " + str(union_list) + "\n")

        # Test split
        split_list = food_list.split()
        f.write("Split: " + str(split_list) + "\n")

        # Test empty list
        empty_list = List()
        f.write("Empty list: " + str(empty_list) + "\n")

if __name__ == "__main__":
    run_list_tests()
