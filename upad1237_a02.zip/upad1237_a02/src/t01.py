"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: prashant upadhyay
ID:  169051237
Email: upad1237@mylaurier.ca
_updated_ = "2024-02-10"
-------------------------------------------------------
"""
TAX_RATE = 18.50

sales = float(input("Enter the total sales : $"))
total = sales*TAX_RATE/100
print("Projected Tax Report")
print("--------------------------")
print(f"Total Sales: $ {sales}")
print(f"Annual Tax: % {TAX_RATE} ")
print("--------------------------")
print(f"Total: {total}")
