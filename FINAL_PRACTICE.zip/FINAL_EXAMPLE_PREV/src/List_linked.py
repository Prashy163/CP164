"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""
#imports
#constants

from copy import deepcopy

class _List_Node:
    def __init__(self, value, _next=None):
        """
        -------------------------------------------------------
        Initializes a list node that contains a copy of value
        and a link to the next node in the list.
        Use: node = _List_Node(value, _next)
        -------------------------------------------------------
        Parameters:
            value - value for node (?)
            _next - another list node (_List_Node)
        Returns:
            a new _List_Node object (_List_Node)
        -------------------------------------------------------
        """
        self._value = deepcopy(value)
        self._next = _next


class List:
    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty list.
        Use: lst = List()
        -------------------------------------------------------
        Returns:
            a new List object (List)
        -------------------------------------------------------
        """
        self._front = None
        self._rear = None
        self._count = 0

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the list is empty.
        Use: b = lst.is_empty()
        -------------------------------------------------------
        Returns:
            True if the list is empty, False otherwise.
        -------------------------------------------------------
        """
        return self._front is None

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the number of values in the list.
        Use: n = len(lst)
        -------------------------------------------------------
        Returns:
            the number of values in the list.
        -------------------------------------------------------
        """
        return self._count

    def prepend(self, value):
        """
        -------------------------------------------------------
        Adds a copy of value to the front of the List.
        Use: lst.prepend(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        # Create the new node.
        node = _List_Node(value, self._front)
        if self._rear is None:
            # List is empty - update the rear of the List.
            self._rear = node
        # Update the front of the List.
        self._front = node
        self._count += 1

    def append(self, value):
        """
        ---------------------------------------------------------
        Adds a copy of value to the end of the List.
        Use: lst.append(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        # Create the new node.
        node = _List_Node(value, None)
        if self._front is None:
            # List is empty - update the front of the List.
            self._front = node
        else:
            self._rear._next = node
        # Update the rear of the List.
        self._rear = node
        self._count += 1

    def insert(self, i, value):
        """
        -------------------------------------------------------
        A copy of value is added to index i, following values are pushed right.
        If i outside of range of -len(list) to len(list) - 1, the value is
        prepended or appended as appropriate.
        Use: lst.insert(i, value)
        -------------------------------------------------------
        Parameters:
            i - index value (int)
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        # Negative index adjustment.
        if i < 0:
            i = self._count + i
        if i <= 0:
            # Add value to the front of the list
            self.prepend(value)
        elif i >= self._count:
            # Add value to the end of the list
            self.append(value)
        else:
            # Add elsewhere in the list - not to front or rear
            j = 0
            previous = None
            current = self._front
            while j < i:
                # Find the proper location in the List
                previous = current
                current = current._next
                j += 1
            # Create the new node.
            node = _List_Node(value, current)
            previous._next = node
            self._count += 1

    def _linear_search(self, key):
        """
        -------------------------------------------------------
        Searches for the first occurrence of key in list.
        Private helper method.
        (iterative algorithm)
        Use: previous, current, index = self._linear_search(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            previous - pointer to the node previous to the node containing key (_List_Node)
            current - pointer to the node containing key (_List_Node)
            index - index of the node containing key (int)
        -------------------------------------------------------
        """
        previous = None
        current = self._front
        index = 0
        while current is not None and current._value != key:
            previous = current
            current = current._next
            index += 1
        if current is None:
            index = -1
        return previous, current, index

    def remove(self, key):
        """
        -------------------------------------------------------
        Finds, removes, and returns the first value in list that matches key.
        Use: value = lst.remove(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            value - the full value matching key, otherwise None (?)
        -------------------------------------------------------
        """
        # Search list for key.
        previous, current, _ = self._linear_search(key)
        if current is None:
            # Key is not found.
            value = None
        else:
            value = current._value
            self._count -= 1
            if previous is None:
                # Remove the first node.
                self._front = self._front._next
                if self._front is None:
                    # List is empty, update _rear.
                    self._rear = None
            else:
                # Remove any other node.
                previous._next = current._next
                if previous._next is None:
                    # Last node was removed, update _rear.
                    self._rear = previous
        return value

    def remove_front(self):
        """
        -------------------------------------------------------
        Removes the first node in the list and returns its value.
        Use: value = lst.remove_front()
        -------------------------------------------------------
        Returns:
            value - the first value in the list (?)
        -------------------------------------------------------
        """
        assert self._front is not None, "Cannot remove from an empty list"
        value = deepcopy(self._front._value)
        self._front = self._front._next
        self._count -= 1
        if self._front is None:
            # List is now empty
            self._rear = None
        return value

    def remove_many(self, key):
        """
        -------------------------------------------------------
        Finds and removes all values in the list that match key.
        Use: lst.remove_many(key)
        -------------------------------------------------------
        Parameters:
            key - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        previous = None
        current = self._front
        while current is not None:
            if current._value == key:
                if previous is None:
                    # Remove the first node
                    self._front = current._next
                    if self._front is None:
                        # List becomes empty
                        self._rear = None
                else:
                    # Remove any other node
                    previous._next = current._next
                    if previous._next is None:
                        # Update rear if the last node is removed
                        self._rear = previous
                self._count -= 1
            else:
                previous = current
            current = current._next

    def find(self, key):
        """
        -------------------------------------------------------
        Finds and returns a copy of the first value in list that matches key.
        Use: value = lst.find(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            value - a copy of the full value matching key, otherwise None (?)
        -------------------------------------------------------
        """
        _, current, _ = self._linear_search(key)
        if current is not None:
            value = deepcopy(current._value)
        else:
            value = None
        return value

    def peek(self):
        """
        -------------------------------------------------------
        Returns a copy of the first value in list.
        Use: value = lst.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the first value in the list (?)
        -------------------------------------------------------
        """
        assert self._front is not None, "Cannot peek at an empty list"
        value = deepcopy(self._front._value)
        return value

    def index(self, key):
        """
        -------------------------------------------------------
        Finds location of a value by key in list.
        Use: n = lst.index(key)
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            i - the index of the location of key in the list, -1 if
                key is not in the list.
        -------------------------------------------------------
        """
        _, _, i = self._linear_search(key)
        return i

    def _is_valid_index(self, i):
        """
        -------------------------------------------------------
        Private helper method to validate an index value.
        Python index values can be positive or negative and range from
        -len(list) to len(list) - 1
        Use: assert self._is_valid_index(i)
        -------------------------------------------------------
        Parameters:
            i - an index value (int)
        Returns:
            True if i is a valid index, False otherwise.
        -------------------------------------------------------
        """
        n = self._count
        return -n <= i < n

    def __getitem__(self, i):
        """
        ---------------------------------------------------------
        Returns a copy of the nth element of the list.
        Use: value = l[i]
        -------------------------------------------------------
        Parameters:
            i - index of the element to access (int)
        Returns:
            value - the i-th element of list (?)
        -------------------------------------------------------
        """
        assert self._is_valid_index(i), "Invalid index value"
        current = self._front
        if i < 0:
            # negative index - convert to positive
            i = self._count + i
        j = 0
        while j < i:
            current = current._next
            j += 1
        value = deepcopy(current._value)
        return value

    def __setitem__(self, i, value):
        """
        ---------------------------------------------------------
        Places a copy of value into the list at position n.
        Use: l[i] = value
        -------------------------------------------------------
        Parameters:
            i - index of the element to access (int)
            value - a data value (?)
        Returns:
            The i-th element of list contains a copy of value. The
            existing value at i is overwritten.
        -------------------------------------------------------
        """
        assert self._is_valid_index(i), "Invalid index value"
        current = self._front
        if i < 0:
            # negative index - convert to positive
            i = self._count + i
        j = 0
        while j < i:
            current = current._next
            j += 1
        current._value = deepcopy(value)

    def __contains__(self, key):
        """
        ---------------------------------------------------------
        Determines if the list contains key.
        Use: b = key in l
        -------------------------------------------------------
        Parameters:
            key - a partial data element (?)
        Returns:
            True if the list contains key, False otherwise.
        -------------------------------------------------------
        """
        _, current, _ = self._linear_search(key)
        return current is not None

    def max(self):
        """
        -------------------------------------------------------
        Finds the maximum value in list.
        Use: value = lst.max()
        -------------------------------------------------------
        Returns:
            max_data - a copy of the maximum value in the list (?)
        -------------------------------------------------------
        """
        assert self._front is not None, "Cannot find maximum of an empty list"
        max_data = self._front._value
        current = self._front._next
        while current is not None:
            if max_data < current._value:
                max_data = current._value
            current = current._next
        return deepcopy(max_data)

    def min(self):
        """
        -------------------------------------------------------
        Finds the minimum value in list.
        Use: value = lst.min()
        -------------------------------------------------------
        Returns:
            min_data - a copy of the minimum value in the list (?)
        -------------------------------------------------------
        """
        assert self._front is not None, "Cannot find minimum of an empty list"
        min_data = self._front._value
        current = self._front._next
        while current is not None:
            if min_data > current._value:
                min_data = current._value
            current = current._next
            
        return deepcopy(min_data)
    
def count(self, key):
    """
    -------------------------------------------------------
    Finds the number of times key appears in list.
    Use: n = lst.count(key)
    -------------------------------------------------------
    Parameters:
        key - a partial data element (?)
    Returns:
        number - number of times key appears in list (int)
    -------------------------------------------------------
    """
    number = 0
    current = self._front
    while current is not None:
        if key == current._value:
            number += 1
        current = current._next
    return number

def reverse(self):
    """
    -------------------------------------------------------
    Reverses the order of the elements in list.
    (iterative algorithm)
    Use: lst.reverse()
    -------------------------------------------------------
    Returns:
        The contents of list are reversed in order with respect
        to their order before the method was called.
    -------------------------------------------------------
    """
    previous = None
    current = self._front
    while current is not None:
        next_node = current._next
        current._next = previous
        previous = current
        current = next_node
    self._front, self._rear = self._rear, self._front
    return

def reverse_r(self):
    """
    -------------------------------------------------------
    Reverses the order of the elements in list.
    (recursive algorithm)
    Use: lst.reverse_r()
    -------------------------------------------------------
    Returns:
        The contents of list are reversed in order with respect
        to their order before the method was called.
    -------------------------------------------------------
    """
    def _reverse_recursive(current, previous):
        if current is None:
            self._front, self._rear = self._rear, self._front
        else:
            next_node = current._next
            current._next = previous
            _reverse_recursive(next_node, current)
        return

    _reverse_recursive(self._front, None)
    return

def clean(self):
    """
    ---------------------------------------------------------
    Removes duplicates from the list. The list contains
    one and only one of each value formerly present in the list.
    The first occurrence of each value is preserved.
    Use: source.clean()
    -------------------------------------------------------
    Returns:
        None
    -------------------------------------------------------
    """
    seen = set()
    previous = None
    current = self._front

    while current is not None:
        if current._value in seen:
            previous._next = current._next
            self._count -= 1
            if previous._next is None:
                self._rear = previous
        else:
            seen.add(current._value)
            previous = current
        current = current._next
    return

def pop(self, *args):
    """
    -------------------------------------------------------
    Finds, removes, and returns the value in list whose index matches i.
    Use: value = lst.pop()
    Use: value = lst.pop(i)
    -------------------------------------------------------
    Parameters:
        args - an array of arguments (tuple of int)
            args[0], if it exists, is the index i
    Returns:
        value - if args exists, the value at position args[0],
            otherwise the last value in the list, value is
            removed from the list (?)
    -------------------------------------------------------
    """
    assert self._front is not None, "Cannot pop from an empty list"
    assert len(args) <= 1, "No more than 1 argument allowed"

    previous = None
    current = self._front

    if len(args) == 1:
        if args[0] < 0:
            n = self._count + args[0]
        else:
            n = args[0]
        j = 0
        while j < n:
            previous = current
            current = current._next
            j += 1
    else:
        while current._next is not None:
            previous = current
            current = current._next

    value = current._value
    self._count -= 1

    if previous is None:
        self._front = self._front._next
        if self._front is None:
            self._rear = None
    else:
        previous._next = current._next
        if previous._next is None:
            self._rear = previous

    return value


def _swap(self, pln, prn):
    """
    -------------------------------------------------------
    Swaps the position of two nodes. The nodes in pln.next and prn.next
    have been swapped, and all links to them updated.
    Use: self._swap(pln, prn)
    -------------------------------------------------------
    Parameters:
        pln - node before list node to swap (_List_Node)
        prn - node before list node to swap (_List_Node)
    Returns:
        None
    -------------------------------------------------------
    """
    if pln is None or prn is None or pln._next is None or prn._next is None:
        return

    node1 = pln._next
    node2 = prn._next
    temp = node2._next

    if node1 == prn:  # adjacent nodes
        node2._next = node1
        node1._next = temp
        pln._next = node2
    elif node2 == pln:  # adjacent nodes in reverse order
        node1._next = node2
        node2._next = temp
        prn._next = node1
    else:
        pln._next = node2
        prn._next = node1
        node2._next, node1._next = node1._next, temp

    return

def is_identical(self, other):
    """
    ---------------------------------------------------------
    Determines whether two lists are identical.
    (iterative version)
    Use: b = lst.is_identical(other)
    -------------------------------------------------------
    Parameters:
        other - another list (List)
    Returns:
        identical - True if this list contains the same values as
        other in the same order, otherwise False.
    -------------------------------------------------------
    """
    current1 = self._front
    current2 = other._front

    while current1 is not None and current2 is not None:
        if current1._value != current2._value:
            return False
        current1 = current1._next
        current2 = current2._next

    return current1 is None and current2 is None

def identical_r(self, other):
    """
    ---------------------------------------------------------
    Determines whether two lists are identical.
    (recursive version)
    Use: b = lst.identical_r(other)
    -------------------------------------------------------
    Parameters:
        other - another list (List)
    Returns:
        identical - True if this list contains the same values as
        other in the same order, otherwise False.
    -------------------------------------------------------
    """
    def _identical_recursive(node1, node2):
        if node1 is None and node2 is None:
            return True
        if node1 is None or node2 is None or node1._value != node2._value:
            return False
        return _identical_recursive(node1._next, node2._next)

    return _identical_recursive(self._front, other._front)

def split(self):
    """
    -------------------------------------------------------
    Splits list into two parts. target1 contains the first half,
    target2 the second half. Current list becomes empty.
    Use: target1, target2 = lst.split()
    -------------------------------------------------------
    Returns:
        target1 - a new List with >= 50% of the original List (List)
        target2 - a new List with <= 50% of the original List (List)
    -------------------------------------------------------
    """
    target1 = List()
    target2 = List()
    mid = self._count // 2 + self._count % 2

    current = self._front
    for i in range(mid):
        target1.append(current._value)
        current = current._next

    while current is not None:
        target2.append(current._value)
        current = current._next

    self._front = None
    self._rear = None
    self._count = 0

    return target1, target2

def split_alt(self):
    """
    -------------------------------------------------------
    Splits the source list into separate target lists with values
    alternating into the targets. At finish source list is empty.
    Order of source values is preserved.
    (iterative algorithm)
    Use: target1, target2 = source.split()
    -------------------------------------------------------
    Returns:
        target1 - contains alternating values from source (List)
        target2 - contains other alternating values from source (List)
    -------------------------------------------------------
    """
    target1 = List()
    target2 = List()
    toggle = True

    while self._front is not None:
        if toggle:
            target1.append(self.pop(0))
        else:
            target2.append(self.pop(0))
        toggle = not toggle

    return target1, target2

def split_alt_r(self):
    """
    -------------------------------------------------------
    Splits the source list into separate target lists with values
    alternating into the targets. At finish source list is empty.
    Order of source values is preserved.
    (recursive algorithm)
    Use: even, odd = lst.split_alt()
    -------------------------------------------------------
    Returns:
        even - the even numbered elements of the list (List)
        odd - the odd numbered elements of the list (List)
    -------------------------------------------------------
    """
    even = List()
    odd = List()

    def _split_recursive(source, is_even):
        if source._front is None:
            return
        value = source.pop(0)
        if is_even:
            even.append(value)
        else:
            odd.append(value)
        _split_recursive(source, not is_even)

    _split_recursive(self, True)
    return even, odd

def _linear_search_r(self, key, current=None, previous=None, index=0):
    """
    -------------------------------------------------------
    Searches for the first occurrence of key in the list.
    Private helper method (recursive version).
    Use: p, c, i = self._linear_search_r(key)
    -------------------------------------------------------
    Parameters:
        key - a partial data element (?)
        current - the current node (_List_Node), defaults to None
        previous - the previous node (_List_Node), defaults to None
        index - the index of the current node (int), defaults to 0
    Returns:
        previous - pointer to the node previous to the node containing key
        current - pointer to the node containing key
        index - index of the node containing key, -1 if key is not found
    -------------------------------------------------------
    """
    if current is None:
        current = self._front  # Start from the front of the list if not provided

    if current is None or current._value == key:
        
        return previous, current, index if current is not None else -1

    # Recurse through the list
    return self._linear_search_r(key, current=current._next, previous=current, index=index + 1)


def intersection(self, source1, source2):
    """
    -------------------------------------------------------
    Update the current list with values that appear in both
    source1 and source2. Values do not repeat.
    (iterative algorithm)
    Use: target.intersection(source1, source2)
    -------------------------------------------------------
    Parameters:
    source1 - a linked list (List)
    source2 - a linked list (List)
    Returns:
    None
    -------------------------------------------------------
    """
    self.clear()
    values1 = set(value for value in source1)
    values2 = set(value for value in source2)
    common = values1.intersection(values2)

    for value in common:
        self.append(value)
        
def intersection_r(self, source1, source2):
    """
    -------------------------------------------------------
    Update the current list with values that appear in both
    source1 and source2. Values do not repeat.
    (recursive algorithm)
    Use: target.intersection(source1, source2)
    -------------------------------------------------------
    Parameters:
    source1 - a linked list (List)
    source2 - a linked list (List)
    Returns:
    None
    -------------------------------------------------------
    """
    def _intersection_r_helper(current1, values2, result):
        if current1 is None:
            return
        if current1._value in values2 and current1._value not in result:
            result.append(current1._value)
        _intersection_r_helper(current1._next, values2, result)

    self.clear()
    values2 = set(value for value in source2)
    _intersection_r_helper(source1._front, values2, self)

def union(self, source1, source2):
    """
    -------------------------------------------------------
    Update the current list with all values that appear in
    source1 and source2. Values do not repeat.
    (iterative algorithm)
    Use: target.union(source1, source2)
    -------------------------------------------------------
    Parameters:
    source1 - a linked list (List)
    source2 - a linked list (List)
    Returns:
    None
    -------------------------------------------------------
    """
    self.clear()
    unique_values = set(value for value in source1)
    unique_values.update(value for value in source2)

    for value in unique_values:
        self.append(value)

def union_r(self, source1, source2):
    """
    -------------------------------------------------------
    Update the current list with all values that appear in
    source1 and source2. Values do not repeat.
    (recursive algorithm)
    Use: target.union(source1, source2)
    -------------------------------------------------------
    Parameters:
    source1 - a linked list (List)
    source2 - a linked list (List)
    Returns:
    None
    -------------------------------------------------------
    """
    def _union_r_helper(current, result):
        if current is None:
            return
        if current._value not in result:
            result.append(current._value)
        _union_r_helper(current._next, result)

    self.clear()
    _union_r_helper(source1._front, self)
    _union_r_helper(source2._front, self)

def clean_r(self):
    """
    ---------------------------------------------------------
    Removes duplicates from the list. (recursive algorithm)
    Use: lst.clean_r()
    -------------------------------------------------------
    Returns:
    The list contains one and only one of each value formerly present
    in the list. The first occurrence of each value is preserved.
    -------------------------------------------------------
    """
    def _clean_r_helper(previous, current, seen):
        if current is None:
            return
        if current._value in seen:
            previous._next = current._next
            if current == self._rear:
                self._rear = previous
            self._count -= 1
        else:
            seen.add(current._value)
            previous = current
        _clean_r_helper(previous, current._next, seen)

    _clean_r_helper(None, self._front, set())

def split_th(self):
    """
    -------------------------------------------------------
    Splits list into two parts. target1 contains the first half,
    target2 the second half. Current list becomes empty.
    Uses Tortoise/Hare algorithm.
    Use: target1, target2 = lst.split()
    -------------------------------------------------------
    Returns:
    target1 - a new List with >= 50% of the original List (List)
    target2 - a new List with <= 50% of the original List (List)
    -------------------------------------------------------
    """
    if self._front is None:
        return List(), List()

    tortoise = self._front
    hare = self._front
    prev = None

    while hare is not None and hare._next is not None:
        prev = tortoise
        tortoise = tortoise._next
        hare = hare._next._next

    target1 = List()
    target2 = List()

    # Split at midpoint
    target1._front = self._front
    target1._rear = prev
    target1._count = self._count // 2 + self._count % 2

    target2._front = tortoise
    target2._rear = self._rear
    target2._count = self._count // 2

    if prev:
        prev._next = None

    self._front = None
    self._rear = None
    self._count = 0

    return target1, target2

    def split_key(self, key):
        """
        Splits list into two parts: 
        - target1: values <= key
        - target2: values > key.
        """
        target1 = List()
        target2 = List()
        while self._front is not None:
            value = self._front._value
            self._front = self._front._next
            if value <= key:
                target1.append(value)
            else:
                target2.append(value)
        self._rear = None
        self._count = 0
        return target1, target2

    def split_apply(self, func):
        """
        Splits list into two parts based on a function:
        - target1: values where func(value) is True
        - target2: values where func(value) is False.
        """
        target1 = List()
        target2 = List()
        while self._front is not None:
            value = self._front._value
            self._front = self._front._next
            if func(value):
                target1.append(value)
            else:
                target2.append(value)
        self._rear = None
        self._count = 0
        return target1, target2

    def copy(self):
        """Creates a duplicate of the list (iterative version)."""
        new_list = List()
        current = self._front
        while current is not None:
            new_list.append(current._value)
            current = current._next
        return new_list

    def copy_r(self):
        """Creates a duplicate of the list (recursive version)."""
        def _copy_recursive(node):
            if node is None:
                return None, None
            new_node = _List_Node(node._value, None)
            new_node._next, rear = _copy_recursive(node._next)
            return new_node, rear or new_node

        new_list = List()
        new_list._front, new_list._rear = _copy_recursive(self._front)
        new_list._count = self._count
        return new_list

    def reverse_pc(self):
        """Reverses the list using partitioning and concatenation."""
        new_list = List()
        while self._front is not None:
            value = self._front._value
            self._front = self._front._next
            new_list.prepend(value)
        self._front = new_list._front
        self._rear = new_list._rear
        self._count = new_list._count

    def _move_front(self, rs):
        """Moves the front node of rs to the front of the current list."""
        assert rs._front is not None, "Cannot move the front of an empty list."
        node = rs._front
        rs._front = node._next
        if rs._front is None:
            rs._rear = None
        rs._count -= 1
        node._next = self._front
        self._front = node
        if self._rear is None:
            self._rear = node
        self._count += 1

    def combine(self, source1, source2):
        """Combines two lists into the current list (iterative version)."""
        while source1._front is not None and source2._front is not None:
            self._move_front(source1)
            self._move_front(source2)
        while source1._front is not None:
            self._move_front(source1)
        while source2._front is not None:
            self._move_front(source2)

    def combine_r(self, source1, source2):
        """Combines two lists into the current list (recursive version)."""
        if source1._front is None and source2._front is None:
            return
        if source1._front is not None:
            self._move_front(source1)
        if source2._front is not None:
            self._move_front(source2)
        self.combine_r(source1, source2)

    def _iter_(self):
        """Generates an iterator for the list."""
        current = self._front
        while current is not None:
            yield current._value
            current = current._next
