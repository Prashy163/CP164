"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  prashant upadhyay
ID:  169051237
Email: upad1237@mylaurier.ca
_updated_ = "2024-02-10"
-------------------------------------------------------
"""
c1 = int(input("Number of pieces of cake: "))
c2 = int(input("Number of party-goers: "))
per_person = (c1//c2)
remaining = c1 % c2
print()
print(f"Pieces of cake per party-goer: {per_person}")
print(f"Pieces of cake left over: {remaining}")
