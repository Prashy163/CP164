"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-04"
-------------------------------------------------------
"""
# Imports

# Constants
from Food import Food
def main():
    key = Food('Spring Rolls', 1, None, None)
    print(key)
    
    
    
main()