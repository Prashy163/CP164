"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""
from functions import dsmvwl
def main():
    s = input("Enter a sentence: ")
    out = dsmvwl(s)
    print("Disemvowelled: {}".format(out))
main()