"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-12-11"
-------------------------------------------------------
"""

#imports
from Deque import Deque

#constants
# Testing insert_rear
d = Deque()

# Insert elements at the rear
d.insert_rear(1)
d.insert_rear(2)
d.insert_rear(3)

print("After inserting at rear:")
current = d._front
while current is not None:
    print(current.value, end=" ")  # Print values in the deque
    current = current.next
print()  # Newline for clarity

# Remove elements from the front and print results
print("Removing from front:")
while d._front is not None:
    print(d.remove_front(), end=" ")  # Print removed values
print()  # Newline for clarity

# Testing reverse and printing results
d.insert_rear(4)
d.insert_rear(5)
d.insert_rear(6)

print("Before reversing:")
current = d._front
while current is not None:
    print(current.value, end=" ")
    current = current.next
print()

d.reverse()

print("After reversing:")
current = d._front
while current is not None:
    print(current.value, end=" ")
    current = current.next
print()

