"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""

from functions import pig_latin
def main():
    word = input("Word: ")
    out = pig_latin(word)
    print("Pig-Latin: {}".format(out))
    
main()