"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""
from functions import file_analyze
def main():
    '''
    f = "test.txt"
    fv = open(f,"r",encoding = "utf-8")
    u,l,d,w,r=file_analyze(fv)
    print("uppers: ",u)
    print("lowers: ",l)
    print("digits: ",d)
    print("whitespace: ",w)
    print("other: ",r)
    
    '''
    
    w = "try"
    if w.__contains__("y"):
        print("Not in it")
main()