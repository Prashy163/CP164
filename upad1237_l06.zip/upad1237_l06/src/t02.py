"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-26"
-------------------------------------------------------
"""

# Imports
from List_linked import List

def test_linear_search():
    """ Test the _linear_search method of the List class. """
    
    
    l = List()  
    l.append(10)
    l.append(20)
    l.append(30)
    l.append(40)
    l.append(50)

    
    previous, found_node, index = l._linear_search(30)
    print("Test Case 1 - Searching for 30:")
    assert found_node is not None, "Expected to find 30 in the list."
    assert found_node._value == 30, "Found value should be 30."
    assert previous._value == 20, "Previous node should be 20."
    assert index == 2, "Should have visited 2 nodes before finding 30."
    print(f"Found: {found_node._value}, Previous: {previous._value}, Index: {index}\n")

    
    previous, found_node, index = l._linear_search(10)
    print("Test Case 2 - Searching for 10:")
    assert found_node is not None, "Expected to find 10 in the list."
    assert found_node._value == 10, "Found value should be 10."
    assert previous is None, "Previous node should be None for the front node."
    assert index == 0, "Should have visited 0 nodes before finding 10."
    print(f"Found: {found_node._value}, Previous: {previous}, Index: {index}\n")

    
    previous, found_node, index = l._linear_search(50)
    print("Test Case 3 - Searching for 50:")
    assert found_node is not None, "Expected to find 50 in the list."
    assert found_node._value == 50, "Found value should be 50."
    assert previous._value == 40, "Previous node should be 40."
    assert index == 4, "Should have visited 4 nodes before finding 50."
    print(f"Found: {found_node._value}, Previous: {previous._value}, Index: {index}\n")

    print("All test cases passed.")


test_linear_search()