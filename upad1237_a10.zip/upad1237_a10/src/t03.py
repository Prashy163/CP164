"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-26"
-------------------------------------------------------
"""
# Imports

from Sorts_array import Sorts
# Constants

a = [30, 25, 4, 67, 25098, 58, 1234321]

print(Sorts.gnome_sort(a))

print(a)