"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""
from functions import max_diff
def main():
    print(max_diff([0,0,0,0]))
    
main()