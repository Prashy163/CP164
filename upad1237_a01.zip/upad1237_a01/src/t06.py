"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""

from functions import matrixes_multiply
def main():
    a = [[1,2,3],
         [4,5,6]]
    b = [[7,8],
         [9,10],
         [11,12]]
    print(matrixes_multiply(a, b))
    
main()