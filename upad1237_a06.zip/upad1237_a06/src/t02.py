"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-30"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue
# Constants

# Test Priority Queue creation and basic operations
pq = Priority_Queue()
print("pq empty (True):", pq.is_empty())
print("pq length (0):", len(pq))

# Test insert (should maintain sorted order)
pq.insert(3)
pq.insert(1)
pq.insert(4)
pq.insert(2)
print("PQ after inserts:", list(pq)) 

# Test remove and peek
print("Peek minimum (1):", pq.peek())
value = pq.remove()
print("Removed value (1):", value)
print("PQ after remove:", list(pq))  