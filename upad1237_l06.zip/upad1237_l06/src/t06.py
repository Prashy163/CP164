"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-10-26"
-------------------------------------------------------
"""
# Imports

# Constants
from List_linked import List


l = List()
l.append(5)
l.append(99)


print("Testing __getitem__ method:")
try:
    print(l[0])  
    print(l[1])  
except AssertionError as e:
    print(f"AssertionError: {e}")  


print("\nTesting __setitem__ method:")
l[0] = 66    
print(l[0])  

try:
    l[1] = 100  
    print(l[1])  
except AssertionError as e:
    print(f"AssertionError: {e}")  


try:
    print(l[2])  
except AssertionError as e:
    print(f"AssertionError: {e}")  