"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-11-16"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set

# Constants
hset = Hash_Set(3)

hset.insert(5)

hset.insert(5)

hset.insert(10)

hset.insert(15)

hset.debug()

