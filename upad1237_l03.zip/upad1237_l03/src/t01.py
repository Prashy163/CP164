"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-27"
-------------------------------------------------------
"""
# Imports

# Constants
from Queue_array import Queue
from PriorityQueue import PriorityQueue
from Food import Food
from Food_utilities import read_foods

def queue_test(foods):
    q = Queue()
    for food in foods:
        q.enqueue(food)

    print("Queue is empty:", q.is_empty())
    print("Front item:", q.peek())

    while not q.is_empty():
        removed_item = q.dequeue()
        print("Removed item:", removed_item)

def priority_queue_test(foods):
    pq = PriorityQueue()
    for food in foods:
        pq.enqueue(food, food.calories)

    print("Priority Queue is empty:", pq.is_empty())
    print("Highest priority item:", pq.peek())

    while not pq.is_empty():
        removed_item = pq.dequeue()
        print("Removed item:", removed_item)

if __name__ == "__main__":
    foods = read_foods('food.txt')  # Ensure the file exists in the correct location
    if foods:  # Check if the list of food is not empty
        queue_test(foods)
        priority_queue_test(foods)
    else:
        print("No food data available for testing.")
