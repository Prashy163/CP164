"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email:   upad1237@mylaurier.ca
__updated__ = "2024-09-28"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import Stack, is_mirror_stack

def test_is_mirror_stack():
    left = Stack()
    right = Stack()

    for char in "abcd":
        left.push(char)

    for char in "dcba":
        right.push(char)

    status = is_mirror_stack(left, right)
    print(f"Left and Right are {status.value}")

test_is_mirror_stack()
