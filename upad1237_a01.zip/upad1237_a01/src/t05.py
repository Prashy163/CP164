"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Prashant Upadhyay
ID:      169051237
Email: upad1237@mylaurier.ca
__updated__ = '2024-09-15'
-------------------------------------------------------
"""

from functions import matrixes_add
def main():
    print(matrixes_add([[1, 1], [2, 3], [4, 5]], [[6, 7], [8, 9], [1, 0]]))

main()

